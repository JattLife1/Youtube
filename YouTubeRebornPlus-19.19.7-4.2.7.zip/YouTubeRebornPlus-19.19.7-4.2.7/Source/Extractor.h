// Extractor.h was made by @LillieH1000 from https://www.github.com/LillieH1000/YouTube-Reborn

#import <Foundation/Foundation.h>

@interface Extractor : NSObject
+ (NSDictionary *)youtubePlayerRequest :(NSString *)client :(NSString *)videoID;
@end
